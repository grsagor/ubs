<tr>
<td class="header">
<a href="<?php echo e($url, false); ?>">
<?php echo e($slot, false); ?>

</a>
</td>
</tr>
<?php /**PATH /home/sites/22a/7/7d090cb412/public_html/oss/resources/views/vendor/mail/html/header.blade.php ENDPATH**/ ?>