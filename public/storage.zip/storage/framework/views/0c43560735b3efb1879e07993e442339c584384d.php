<?php if(isset($content)): ?>
 <?php echo $content; ?>

<?php endif; ?><?php /**PATH /home/sites/22a/7/7d090cb412/public_html/oss/resources/views/emails/plain_html.blade.php ENDPATH**/ ?>