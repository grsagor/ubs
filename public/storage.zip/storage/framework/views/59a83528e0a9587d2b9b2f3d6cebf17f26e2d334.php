<?php echo e($slot, false); ?>

<?php /**PATH /home/sites/22a/7/7d090cb412/public_html/oss/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>