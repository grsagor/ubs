<div id="<?php echo e($chart->id, false); ?>" <?php echo $chart->formatContainerOptions('css'); ?>>
</div>
<?php echo $__env->make('charts::loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/sites/22a/7/7d090cb412/public_html/oss/vendor/consoletvs/charts/src/Views/highcharts/container.blade.php ENDPATH**/ ?>