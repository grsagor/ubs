<tr>
<td>
<table class="footer" align="center" width="570" cellpadding="0" cellspacing="0">
<tr>
<td class="content-cell" align="center">
<?php echo e(Illuminate\Mail\Markdown::parse($slot), false); ?>

</td>
</tr>
</table>
</td>
</tr>
<?php /**PATH /home/sites/22a/7/7d090cb412/public_html/oss/resources/views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>