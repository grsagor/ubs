<?php if(!empty($shift_info)): ?>
	<h4>
		<?php echo e(ucfirst($shift_info->name), false); ?>

		<small>
			(
				<code>
					<?php echo app('translator')->get('essentials::lang.'.$shift_info->type); ?>
				</code>
			)
		</small>
	</h4>
	<?php if($shift_info->type == 'fixed_shift'): ?>
		<b><?php echo app('translator')->get('restaurant.start_time'); ?>:</b> <?php echo e(\Carbon::createFromTimestamp(strtotime($shift_info->start_time))->format('H:i'), false); ?> 
		<br>
		<b><?php echo app('translator')->get('restaurant.end_time'); ?>:</b> <?php echo e(\Carbon::createFromTimestamp(strtotime($shift_info->end_time))->format('H:i'), false); ?>

	<?php endif; ?>
<?php endif; ?><?php /**PATH /home/sites/22a/7/7d090cb412/public_html/oss/Modules/Essentials/Providers/../Resources/views/attendance/current_shift.blade.php ENDPATH**/ ?>