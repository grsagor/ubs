<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <?php echo Form::label('subject', __('crm::lang.subject') . ':*' ); ?>

            <?php echo Form::text('subject',!empty($proposal_template) ? $proposal_template->subject : '', ['class' => 'form-control', 'required' ]); ?>

       </div>
    </div>
</div>
<div class="row">
	<div class="col-md-12">
        <div class="form-group">
            <?php echo Form::label('body', __('crm::lang.email_body') . ':*'); ?>

            <?php echo Form::textarea('body', !empty($proposal_template) ? $proposal_template->body : '', ['class' => 'form-control', 'id' => 'proposal_email_body','required']); ?>

        </div>
        <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        	<label id="proposal_email_body-error" class="error" for="body">
        		<?php echo e($message, false); ?>

        	</label>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php if($attachments): ?>
	<div class="row">
		<div class="col-sm-12">
	      <div class="form-group">
	        <?php echo Form::label('attachments', __('crm::lang.attachments') . ':'); ?>

	        <?php echo Form::file('attachments[]', ['id' => 'attachments', 'accept' => implode(',', array_keys(config('constants.document_upload_mimes_types'))), 'multiple']); ?>

	        <small>
	        	<p class="help-block">
	        		<p class="help-block">
	                    <?php echo app('translator')->get('purchase.max_file_size', ['size' => (config('constants.document_size_limit') / 1000000)]); ?>
	                    <?php if ($__env->exists('components.document_help_text')) echo $__env->make('components.document_help_text', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	                </p>
	        	</p>
	        </small>
	      </div>
	    </div>
	</div>
<?php endif; ?><?php /**PATH /home/sites/22a/7/7d090cb412/public_html/oss/Modules/Crm/Providers/../Resources/views/proposal_template/partials/template_form.blade.php ENDPATH**/ ?>