<input type="hidden" id="contact_id_for_login" value="<?php echo e($contact->id, false); ?>">
<li>
   <a href="#login" data-toggle="tab" aria-expanded="true">
       <i class="fas fa-user-plus"></i>
       <?php echo app('translator')->get('crm::lang.contact_persons'); ?>
   </a> 
</li><?php /**PATH /home/sites/22a/7/7d090cb412/public_html/oss/Modules/Crm/Providers/../Resources/views/contact_login/partial/tab_menu.blade.php ENDPATH**/ ?>