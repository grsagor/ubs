
<?php $__env->startSection('title', __('restaurant.bookings')); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1><?php echo app('translator')->get( 'restaurant.bookings' ); ?></h1>
    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
    </ol> -->
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        
    </div>
    <br>
    <div class="row">
        <div class="col-sm-12">
            <div class="box box-primary">
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6">
                            <?php if(count($business_locations) > 1): ?>
                            <select id="business_location_id" class="select2" style="width:60%">
                                <option value=""><?php echo app('translator')->get('purchase.business_location'); ?></option>
                                <?php $__currentLoopData = $business_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key, false); ?>"><?php echo e($value, false); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6 mb-12">
                            <button type="button" class="btn btn-primary pull-right" id="add_new_booking_btn"><i class="fa fa-plus"></i> <?php echo app('translator')->get('restaurant.add_booking'); ?></button>
                        </div>
                        <div class="col-md-12">
                            <table class="table table-bordered table-condensed" id="bookings_table">
                                <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('restaurant.booking_starts'); ?></th>
                                    <th><?php echo app('translator')->get('restaurant.booking_ends'); ?></th>
                                    <th><?php echo app('translator')->get('sale.status'); ?></th>
                                    <th><?php echo app('translator')->get('messages.location'); ?></th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </div>

</section>
<!-- /.content -->
<?php echo $__env->make('crm::booking.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    
    <script type="text/javascript">
        $(document).ready(function(){
            $('#add_booking_modal').on('shown.bs.modal', function (e) {
                $(this).find('select').each( function(){
                    if(!($(this).hasClass('select2'))){
                        $(this).select2({
                            dropdownParent: $('#add_booking_modal')
                        });
                    }
                });
                booking_form_validator = $('form#add_booking_form').validate({
                    submitHandler: function(form) {
                        $(form).find('button[type="submit"]').attr('disabled', true);
                        var data = $(form).serialize();

                        $.ajax({
                            method: "POST",
                            url: $(form).attr("action"),
                            dataType: "json",
                            data: data,
                            success: function(result){
                                if(result.success == true){
                                    $('div#add_booking_modal').modal('hide');
                                    toastr.success(result.msg);
                                    bookings_table.ajax.reload();
                                } else {
                                    toastr.error(result.msg);
                                }
                                $(form).find('button[type="submit"]').attr('disabled', false);
                                reset_booking_form();
                            }
                        });
                    }
                });
            });

            $('form#add_booking_form #start_time').datetimepicker({
                format: moment_date_format + ' ' +moment_time_format,
                minDate: moment(),
                ignoreReadonly: true
            });
            
            $('form#add_booking_form #end_time').datetimepicker({
                format: moment_date_format + ' ' +moment_time_format,
                minDate: moment(),
                ignoreReadonly: true,
            });

            bookings_table = $('#bookings_table').DataTable({
                            processing: true,
                            serverSide: true,
                            "ajax": {
                                "url": "<?php echo e(action('\Modules\Crm\Http\Controllers\ContactBookingController@index'), false); ?>",
                                "data": function ( d ) {
                                    d.location_id = $('#business_location_id').val();
                                }
                            },
                            columns: [
                                {data: 'booking_start', name: 'booking_start'},
                                {data: 'booking_end', name: 'booking_end'},
                                {data: 'booking_status'},
                                {data: 'location_name', name: 'bl.name'},
                            ]
                        });
            $('button#add_new_booking_btn').click( function(){
                $('div#add_booking_modal').modal('show');
            });

        });

        $(document).on('change', 'select#business_location_id', function(){
            bookings_table.ajax.reload();
        });

        function reset_booking_form(){
            $('select#booking_location_id').val('').change();
            $('#booking_note, #start_time, #end_time').val('');
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('crm::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\New folder\htdocs\UltimatePOS-V5.0\ultimatepos\Modules\Crm\Providers/../Resources/views/booking/index.blade.php ENDPATH**/ ?>