<div class="direct-chat-msg">
  	<div class="direct-chat-info clearfix">
    	<span class="direct-chat-name pull-left"><?php echo e($comment->added_by->user_full_name, false); ?></span>
    	<span class="direct-chat-timestamp pull-right"><?php echo e(\Carbon::createFromTimestamp(strtotime($comment->created_at))->format(session('business.date_format') . ' ' . 'H:i'), false); ?></span>
  	</div>

  	<div class="direct-chat-text" style="margin-left: 0;">
    	<?php echo e($comment->comment, false); ?>


    	<?php if(auth()->user()->id == $comment->comment_by): ?>
    		<i class="delete-comment fa fa-trash pull-right text-danger" style="cursor: pointer;" data-comment_id="<?php echo e($comment->id, false); ?>"></i>
    	<?php endif; ?>
  	</div>
</div><?php /**PATH /home/sites/22a/7/7d090cb412/public_html/oss/Modules/Essentials/Providers/../Resources/views/todo/comment.blade.php ENDPATH**/ ?>